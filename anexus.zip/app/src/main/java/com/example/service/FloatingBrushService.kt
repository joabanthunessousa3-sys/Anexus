package com.example.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast

class FloatingBrushService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.anexus.ACTION_SHOW_BRUSH"
        const val ACTION_HIDE = "com.example.anexus.ACTION_HIDE_BRUSH"
        const val ACTION_TOGGLE = "com.example.anexus.ACTION_TOGGLE_BRUSH"

        var isBrushActive: Boolean = false
    }

    private var windowManager: WindowManager? = null
    private var rootOverlay: FrameLayout? = null
    private var canvasView: DrawingCanvasView? = null

    private var currentColor = Color.parseColor("#EF4444") // Red default
    private var currentStrokeWidth = 10f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showBrushOverlay()
            ACTION_HIDE -> hideBrushOverlay()
            ACTION_TOGGLE -> {
                if (isBrushActive) hideBrushOverlay() else showBrushOverlay()
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBrushOverlay() {
        if (rootOverlay != null) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permissão de sobreposição necessária para o Pincel", Toast.LENGTH_SHORT).show()
            stopSelf()
            return
        }

        val dpToPx = { dp: Int ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(),
                resources.displayMetrics
            ).toInt()
        }

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        val root = FrameLayout(this)

        val drawingView = DrawingCanvasView(this)
        canvasView = drawingView
        root.addView(drawingView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Floating Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EE121524"))
                cornerRadius = dpToPx(24).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#558B5CF6"))
            }
            background = bg
            elevation = dpToPx(8).toFloat()

            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dpToPx(40)
            }
        }

        // Color chips
        val colors = listOf(
            "#EF4444" to "Vermelho",
            "#A855F7" to "Roxo",
            "#06B6D4" to "Ciano",
            "#F59E0B" to "Amarelo",
            "#FFFFFF" to "Branco"
        )

        for ((hex, _) in colors) {
            val colorView = View(this).apply {
                val circle = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                    setStroke(dpToPx(2), if (hex == "#EF4444") Color.WHITE else Color.TRANSPARENT)
                }
                background = circle
                val size = dpToPx(24)
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    marginEnd = dpToPx(8)
                }
                setOnClickListener {
                    currentColor = Color.parseColor(hex)
                    drawingView.setColor(currentColor)
                    // Update borders
                    for (i in 0 until colors.size) {
                        val child = toolbar.getChildAt(i)
                        val childHex = colors[i].first
                        (child.background as? GradientDrawable)?.setStroke(
                            dpToPx(2),
                            if (childHex == hex) Color.WHITE else Color.TRANSPARENT
                        )
                    }
                }
            }
            toolbar.addView(colorView)
        }

        // Clear button
        val clearBtn = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_delete)
            setColorFilter(Color.parseColor("#94A3B8"))
            layoutParams = LinearLayout.LayoutParams(dpToPx(26), dpToPx(26)).apply {
                marginEnd = dpToPx(10)
                marginStart = dpToPx(4)
            }
            setOnClickListener {
                drawingView.clear()
            }
        }
        toolbar.addView(clearBtn)

        // Close brush button
        val closeBtn = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setColorFilter(Color.parseColor("#EF4444"))
            layoutParams = LinearLayout.LayoutParams(dpToPx(26), dpToPx(26))
            setOnClickListener {
                hideBrushOverlay()
            }
        }
        toolbar.addView(closeBtn)

        root.addView(toolbar)

        rootOverlay = root
        isBrushActive = true

        try {
            windowManager?.addView(root, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideBrushOverlay() {
        rootOverlay?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        rootOverlay = null
        canvasView = null
        isBrushActive = false
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        hideBrushOverlay()
    }

    private class DrawingCanvasView(context: Context) : View(context) {
        private val paths = mutableListOf<Pair<Path, Paint>>()
        private var currentPath = Path()
        private var currentPaint = Paint().apply {
            color = Color.parseColor("#EF4444")
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            strokeWidth = 10f
            isAntiAlias = true
        }

        fun setColor(color: Int) {
            currentPaint = Paint(currentPaint).apply {
                this.color = color
            }
        }

        fun clear() {
            paths.clear()
            currentPath.reset()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            for ((path, paint) in paths) {
                canvas.drawPath(path, paint)
            }
            canvas.drawPath(currentPath, currentPaint)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    currentPath = Path()
                    currentPath.moveTo(x, y)
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    currentPath.lineTo(x, y)
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    currentPath.lineTo(x, y)
                    paths.add(Pair(Path(currentPath), Paint(currentPaint)))
                    currentPath.reset()
                    invalidate()
                    return true
                }
            }
            return super.onTouchEvent(event)
        }
    }
}
